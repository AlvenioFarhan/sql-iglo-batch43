--BELUM SELESAI
--13) Add New Competency.sql
--Buatlah sebuah procedure yang berfungsi untuk memberikan kompetensi seorang tutor terhadap sebuah subject. 
--Procedure akan meminta 2 input parameter, yaitu existing Staff Number dan existing subject code, dan kedua hal ini 
--akan dikaitkan dalam kompetensi. Procedure harus memiliki validasi dan harus bisa memberikan error massage apabila tutor 
--dengan staff number yang input tidak ada pada database atau apabila subject dengan subject code yang diinput tidak ada pada database. 
--Dan apabila salah satu tidak exist pada database, competency tidak jadi ditambahkan.

select * from Tutor